// USTAWIONO: 4 października 2025, 06:00:00 RANO
// MIESIĄCE są liczone od 0 (0=styczeń, 9=październik, 11=grudzień)
const DATA_ZAGINIECIA = new Date(2025, 9, 4, 12, 0, 0).getTime(); 

const licznikCzasu = setInterval(function() {
    // Pobierz aktualny czas
    const teraz = new Date().getTime();
    // Oblicz różnicę (ile czasu minęło)
    const roznica = teraz - DATA_ZAGINIECIA;

    // Obliczenia Dni, Godzin, Minut
    const dni = Math.floor(roznica / (1000 * 60 * 60 * 24));
    const godziny = Math.floor((roznica % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minuty = Math.floor((roznica % (1000 * 60 * 60)) / (1000 * 60));

    // Znajdź element licznika w HTML
    const elementLicznika = document.getElementById("licznik");

    if (elementLicznika) {
        elementLicznika.innerHTML = `
            <span style="color: red; font-size: 1.8em; font-weight: bold;">
                ${dni} DNI, ${godziny} GODZ., ${minuty} MIN.
            </span>
            <br>
            <span style="font-size: 0.9em; color: #555;">(od zaginięcia Karmela)</span>
        `;
    }
}, 1000);